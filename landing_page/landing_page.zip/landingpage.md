1. Create the html files
    + 'index.html'
    + 'ninjas.html'
    + 'dojos.html'
    + 'app.js'
2. Create Node server    
    1. Set the dependencies (requirements)
        + 'fs'
        + 'http'
    2. var server = http.createServer(
    3. Link http requests to urls then link urls to html files
    4. Read the html file and send back to browser.
