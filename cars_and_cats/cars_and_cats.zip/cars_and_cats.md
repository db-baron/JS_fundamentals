1. Create the html files (go in views directory)
    + 'cars.html'
    + 'cats.html'
    + 'cats/new.html'
2. Create Node server    
    1. Set the dependencies (requirements)
        + 'fs'
        + 'http'
    2. Use line of code: var server = http.createServer(
    3. Link http requests to urls then link urls to html files
    4. Read the html file and send back to browser.
